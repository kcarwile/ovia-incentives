<?php

use MWP\Framework\Symfony\Collator as IntlCollator;

/**
 * Stub implementation for the Collator class of the intl extension.
 */
class Collator extends IntlCollator
{
}
