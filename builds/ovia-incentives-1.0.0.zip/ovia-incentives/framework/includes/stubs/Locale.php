<?php

use MWP\Framework\Symfony\Locale as IntlLocale;

/**
 * Stub implementation for the Locale class of the intl extension.
 */
class Locale extends IntlLocale
{
}
